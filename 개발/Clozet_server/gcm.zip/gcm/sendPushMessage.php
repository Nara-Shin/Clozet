<?php
	header('Content-Type: text/html; charset=utf-8');

    include "GCMPushMessage.php";
	
	$apiKey = "AIzaSyCpivM9DGAx8PuC_MubgjQpy7XszkCviZ8";
	$devices = array('APA91bFAa9nYbrIV23JAljm_xnljM4f84WpEb0SWjx5pph3FxgIFd_QaM1O2Z0BrkeFt0YBhEX3ggNvPac63PqVqC5AOC-yKnRgzUpToLQd42qaoN0IsBZtKMA2Qze6lHkffWm4K0NQH');
	$message = "The message to send";

	$gcpm = new GCMPushMessage($apiKey);
	$gcpm->setDevices($devices);
	$response = $gcpm->send($message);
	
	echo $response;
?>