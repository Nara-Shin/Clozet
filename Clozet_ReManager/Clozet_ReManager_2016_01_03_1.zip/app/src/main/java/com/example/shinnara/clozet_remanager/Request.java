package com.example.shinnara.clozet_remanager;

/**
 * Created by ShinNara on 2015-11-25.
 */
public class Request {
    int room;
    String name;

    public int getRoom() {
        return room;
    }

    public String getName() {
        return name;
    }

    public void setRoom(int room) {
        this.room = room;
    }

    public void setName(String name) {
        this.name = name;
    }

}
